<div class="page-contain contact-us">

    <!-- Main content -->
    <div id="main-content" class="main-content">


        <div class="container">

            <div class="row">

                <!--Contact info-->
                <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="contact-info-container sm-margin-top-27px xs-margin-bottom-60px xs-margin-top-60px">
                        <h4 class="box-title">Make Payment</h4>
                        <p class="frst-desc">Contrary to popular belief, Lorem Ipsum is not simply random text. It has
                            roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.
                        </p>
                        <ul class="addr-info">
                            <li>
                                <div class="if-item">
                                    <b class="tie">Full name :</b>
                                    <p class="dsc"><?php echo $result['register_name']; ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="if-item">
                                    <b class="tie">Phone:</b>
                                    <p class="dsc"><?php echo $result['phonenumber']; ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="if-item">
                                    <b class="tie">Total Amount:</b>
                                    <p class="dsc"><?php echo $result['total_amount']; ?></p>
                                </div>
                            </li>
                            <li>
                                <div class="if-item">
                                    <b class="tie">Bank Name </b>
                                    <p class="dsc">Providus Bank</p>
                                </div>
                            </li>
                            <li>
                                <div class="if-item">
                                    <b class="tie">Bank Account Number :</b>
                                    <p class="dsc"><?php echo $result['account_no']; ?></p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div> -->

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="contact-info-container sm-margin-top-27px xs-margin-bottom-60px xs-margin-top-60px">
        <h4 class="box-title" style="font-size: 28px; font-weight: bold;">Make Payment</h4>
        <p class="frst-desc" style="font-size: 18px; color: #555; line-height: 1.5;">
            Please review your payment details below. Ensure all information is correct before proceeding with your payment.
        </p>
        <ul class="addr-info" style="list-style-type: none; padding: 0; margin-top: 20px;">
            <li>
                <div class="if-item" style="margin-bottom: 15px;">
                    <b class="tie" style="font-size: 20px;">Full Name:</b>
                    <p class="dsc" style="font-size: 18px;"><?php echo $result['register_name']; ?></p>
                </div>
            </li>
            <li>
                <div class="if-item" style="margin-bottom: 15px;">
                    <b class="tie" style="font-size: 20px;">Phone:</b>
                    <p class="dsc" style="font-size: 18px;"><?php echo $result['phonenumber']; ?></p>
                </div>
            </li>
            <li>
                <div class="if-item" style="margin-bottom: 15px;">
                    <b class="tie" style="font-size: 20px;">Total Amount:</b>
                    <p class="dsc" style="font-size: 18px;"><?php echo $result['total_amount']; ?></p>
                </div>
            </li>
            <li>
                <div class="if-item" style="margin-bottom: 15px;">
                    <b class="tie" style="font-size: 20px;">Bank Name:</b>
                    <p class="dsc" style="font-size: 18px;">Providus Bank</p>
                </div>
            </li>
            <li>
                <div class="if-item" style="margin-bottom: 15px;">
                    <b class="tie" style="font-size: 20px;">Bank Account Number:</b>
                    <p class="dsc" style="font-size: 18px;"><?php echo $result['account_no']; ?></p>
                </div>
            </li>
        </ul>
    </div>
</div>




            </div>
        </div>
    </div>
</div>